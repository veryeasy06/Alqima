import Alqima from "./Alqima.jsx";

export default function App() {
  return <Alqima />;
}
